"""Tests for XINACHAIN."""
